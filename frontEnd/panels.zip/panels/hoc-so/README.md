This panel folder has been renamed to `hoc-chu-so` for clarity.

The new module is located at `panels/hoc-chu-so/` and `main.js` has been updated to load that module.

You can safely remove this folder if you don't need the old copy.